var searchData=
[
  ['filterreviewsbyservice_0',['FilterReviewsByService',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#a23151e958366e55aeadcf1aa0a1c3d5d',1,'LusoHealthClient.Server.Controllers.ProfileController.FilterReviewsByService(int id)'],['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#abf8ac68dae16868b19e495b9ffa72939',1,'LusoHealthClient.Server.Controllers.ProfileController.FilterReviewsByService(int idSpecialty, string idProfessional)']]],
  ['finishappointment_1',['FinishAppointment',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_appointment_controller.html#a1cb709d02679b56004c5b260d6a21c2b',1,'LusoHealthClient::Server::Controllers::AppointmentController']]],
  ['forgotpassword_2',['ForgotPassword',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a3e8d4c7ad748974549c149f0a12f201c',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]]
];
