var searchData=
[
  ['makeappointmentdto_0',['MakeAppointmentDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_services_1_1_make_appointment_dto.html',1,'LusoHealthClient::Server::DTOs::Services']]],
  ['managecontroller_1',['ManageController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html',1,'LusoHealthClient::Server::Controllers']]],
  ['message_2',['Message',['../class_luso_health_client_1_1_server_1_1_models_1_1_chat_1_1_message.html',1,'LusoHealthClient::Server::Models::Chat']]],
  ['messagedto_3',['MessageDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_chat_1_1_message_dto.html',1,'LusoHealthClient::Server::DTOs::Chat']]]
];
