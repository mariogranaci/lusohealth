var searchData=
[
  ['sd_0',['SD',['../class_luso_health_client_1_1_server_1_1_s_d.html',1,'LusoHealthClient::Server']]],
  ['service_1',['Service',['../class_luso_health_client_1_1_server_1_1_models_1_1_professionals_1_1_service.html',1,'LusoHealthClient::Server::Models::Professionals']]],
  ['servicedto_2',['ServiceDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_profile_1_1_service_dto.html',1,'LusoHealthClient::Server::DTOs::Profile']]],
  ['servicesdto_3',['ServicesDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_services_1_1_services_dto.html',1,'LusoHealthClient::Server::DTOs::Services']]],
  ['specialty_4',['Specialty',['../class_luso_health_client_1_1_server_1_1_models_1_1_professionals_1_1_specialty.html',1,'LusoHealthClient::Server::Models::Professionals']]],
  ['specialtydto_5',['SpecialtyDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_profile_1_1_specialty_dto.html',1,'LusoHealthClient::Server::DTOs::Profile']]],
  ['subject_6',['Subject',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_email_send_dto.html#ac10eaf3eb61ac90d4d73150b36caca1e',1,'LusoHealthClient::Server::DTOs::Authentication::EmailSendDto']]],
  ['suspendaccountpatient_7',['SuspendAccountPatient',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a4e94c4524872fdfe1e33bfa9dcf98a01',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['suspendaccountprofessional_8',['SuspendAccountProfessional',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a6a5e933275f56e946abf9efecc2fd20e',1,'LusoHealthClient::Server::Controllers::ManageController']]]
];
