var searchData=
[
  ['backofficecontroller_0',['BackOfficeController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_luso_health_client_1_1_server_1_1_contro3f53c81340918213c92e788826d2c06c.html',1,'LusoHealthClient::Server::Controllers::LusoHealthClient::Server::Controllers']]],
  ['boundsdto_1',['BoundsDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_services_1_1_bounds_dto.html',1,'LusoHealthClient::Server::DTOs::Services']]]
];
