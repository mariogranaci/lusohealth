var searchData=
[
  ['deleteslotsdto_0',['DeleteSlotsDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_agenda_1_1_delete_slots_dto.html',1,'LusoHealthClient::Server::DTOs::Agenda']]],
  ['descriptiondto_1',['DescriptionDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_profile_1_1_description_dto.html',1,'LusoHealthClient::Server::DTOs::Profile']]]
];
