var searchData=
[
  ['homecontroller_0',['HomeController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_home_controller.html',1,'LusoHealthClient::Server::Controllers']]]
];
