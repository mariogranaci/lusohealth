var searchData=
[
  ['refundrequestdto_0',['RefundRequestDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_services_1_1_refund_request_dto.html',1,'LusoHealthClient::Server::DTOs::Services']]],
  ['registerdto_1',['RegisterDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_register_dto.html',1,'LusoHealthClient::Server::DTOs::Authentication']]],
  ['registerwithgoogledto_2',['RegisterWithGoogleDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_register_with_google_dto.html',1,'LusoHealthClient::Server::DTOs::Authentication']]],
  ['relative_3',['Relative',['../class_luso_health_client_1_1_server_1_1_models_1_1_users_1_1_relative.html',1,'LusoHealthClient::Server::Models::Users']]],
  ['relativedto_4',['RelativeDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_profile_1_1_relative_dto.html',1,'LusoHealthClient::Server::DTOs::Profile']]],
  ['report_5',['Report',['../class_luso_health_client_1_1_server_1_1_models_1_1_feedback_and_reports_1_1_report.html',1,'LusoHealthClient::Server::Models::FeedbackAndReports']]],
  ['reportdto_6',['ReportDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_administration_1_1_report_dto.html',1,'LusoHealthClient::Server::DTOs::Administration']]],
  ['resetpassworddto_7',['ResetPasswordDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_reset_password_dto.html',1,'LusoHealthClient::Server::DTOs::Authentication']]],
  ['review_8',['Review',['../class_luso_health_client_1_1_server_1_1_models_1_1_feedback_and_reports_1_1_review.html',1,'LusoHealthClient::Server::Models::FeedbackAndReports']]],
  ['reviewadmindto_9',['ReviewAdminDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_administration_1_1_review_admin_dto.html',1,'LusoHealthClient::Server::DTOs::Administration']]],
  ['reviewdto_10',['ReviewDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_profile_1_1_review_dto.html',1,'LusoHealthClient::Server::DTOs::Profile']]],
  ['rolescontroller_11',['RolesController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_roles_controller.html',1,'LusoHealthClient::Server::Controllers']]]
];
