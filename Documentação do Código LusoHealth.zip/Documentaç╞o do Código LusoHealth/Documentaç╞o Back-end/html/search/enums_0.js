var searchData=
[
  ['appointmentstate_0',['AppointmentState',['../namespace_luso_health_client_1_1_server_1_1_models_1_1_services.html#a90e732e1a4aee1247b0f4ae26cf26933',1,'LusoHealthClient::Server::Models::Services']]],
  ['appointmenttype_1',['AppointmentType',['../namespace_luso_health_client_1_1_server_1_1_models_1_1_services.html#a3cd8102f0e80ef82b4b1a1a9177b1783',1,'LusoHealthClient::Server::Models::Services']]]
];
