var searchData=
[
  ['backofficecontroller_0',['BackOfficeController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_luso_health_client_1_1_server_1_1_contro3f53c81340918213c92e788826d2c06c.html#ad77b689efe4a22e872d7be66a49fe322',1,'LusoHealthClient::Server::Controllers::LusoHealthClient::Server::Controllers::BackOfficeController']]],
  ['beginappointment_1',['BeginAppointment',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_appointment_controller.html#a02965635467a7d6c7e6e28fea6ee69a2',1,'LusoHealthClient::Server::Controllers::AppointmentController']]],
  ['blockaccountpatient_2',['BlockAccountPatient',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a3088c709a48e489810602faf6ead4678',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['blockaccountprofessional_3',['BlockAccountProfessional',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a2e16c7ebb4035f1abc0c3018be2d84a5',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['buildtargetmodel_4',['BuildTargetModel',['../class_luso_health_client_1_1_server_1_1_migrations_1_1_luso_health.html#a5f48d5e8681bd6b6dc38029791762fb6',1,'LusoHealthClient::Server::Migrations::LusoHealth']]]
];
