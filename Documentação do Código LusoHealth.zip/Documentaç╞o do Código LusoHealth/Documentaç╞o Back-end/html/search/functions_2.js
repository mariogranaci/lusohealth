var searchData=
[
  ['cancelappointment_0',['CancelAppointment',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_appointment_controller.html#adfcd62a8fd158d31ae04a8323950f3f0',1,'LusoHealthClient.Server.Controllers.AppointmentController.CancelAppointment()'],['../class_luso_health_client_1_1_server_1_1_controllers_1_1_payment_controller.html#a378472a01b6f4814b76be604f8506e7f',1,'LusoHealthClient.Server.Controllers.PaymentController.CancelAppointment()']]],
  ['changeappointment_1',['ChangeAppointment',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_appointment_controller.html#a37470f8c553d2cd7ff0583d79b54396f',1,'LusoHealthClient::Server::Controllers::AppointmentController']]],
  ['changeappointmentstate_2',['ChangeAppointmentState',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_payment_controller.html#a4be46fc892d5666df068b5cdae5fbb58',1,'LusoHealthClient::Server::Controllers::PaymentController']]],
  ['concludereport_3',['ConcludeReport',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a5f1fda99164bd1adf86089f49950eb5d',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['confirmemail_4',['ConfirmEmail',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a39d6b75866ed77693b36daf497901765',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['createcheckoutsession_5',['CreateCheckoutSession',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_payment_controller.html#a5ef076d30413d6483db52dc835923357',1,'LusoHealthClient::Server::Controllers::PaymentController']]]
];
