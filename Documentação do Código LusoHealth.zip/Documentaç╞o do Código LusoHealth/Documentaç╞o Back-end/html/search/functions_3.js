var searchData=
[
  ['deletepdf_0',['DeletePdf',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#abdddd3f9ade3d427803b32822abf39b3',1,'LusoHealthClient::Server::Controllers::ProfileController']]],
  ['deleterelative_1',['DeleteRelative',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#ac650749a667660455a032ad62bf5be6f',1,'LusoHealthClient::Server::Controllers::ProfileController']]],
  ['deletereview_2',['DeleteReview',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a2bdaf440c942d2340f5f377510a04c76',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['deleteservice_3',['DeleteService',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#a28ca5a128cafab8c199580fd650e32e6',1,'LusoHealthClient::Server::Controllers::ProfileController']]],
  ['deleteslots_4',['DeleteSlots',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_agenda_controller.html#a1dd2468fab87ca10558707488c683f7f',1,'LusoHealthClient::Server::Controllers::AgendaController']]],
  ['down_5',['Down',['../class_luso_health_client_1_1_server_1_1_migrations_1_1_luso_health.html#af5c89152521284035242948318777e74',1,'LusoHealthClient::Server::Migrations::LusoHealth']]],
  ['downloadpdf_6',['DownloadPdf',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_profile_controller.html#a084bcd8c9f425f003964a769b0ab1b18',1,'LusoHealthClient::Server::Controllers::ProfileController']]]
];
