var searchData=
[
  ['emailsenddto_0',['EmailSendDto',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_email_send_dto.html#ad01256291247742af08eb6e960cd408e',1,'LusoHealthClient::Server::DTOs::Authentication::EmailSendDto']]]
];
