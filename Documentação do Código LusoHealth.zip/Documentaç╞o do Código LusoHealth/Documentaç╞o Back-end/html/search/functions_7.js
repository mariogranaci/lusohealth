var searchData=
[
  ['homecontroller_0',['HomeController',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_home_controller.html#a0812e79e16325b2713a27cc0812158d8',1,'LusoHealthClient::Server::Controllers::HomeController']]]
];
