var searchData=
[
  ['login_0',['Login',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a1e07cea8c2bc51d45c9ed5a0d8a85887',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['loginwithgoogle_1',['LoginWithGoogle',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#aaaaba2ba6fbb53ac57a921e23300c801',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]]
];
