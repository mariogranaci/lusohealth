var searchData=
[
  ['recoveraccount_0',['RecoverAccount',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a555138f6614ae05d6812c0027cb68a52',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['refreshusertoken_1',['RefreshUserToken',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a528cc9495df01cdbbe86747242d8fe8d',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['refundappointment_2',['RefundAppointment',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_payment_controller.html#abe638a4d2f9ef2d4678119ddaec5c354',1,'LusoHealthClient::Server::Controllers::PaymentController']]],
  ['register_3',['Register',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a49846d35d119ff88c8e0856efa02be81',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['registerwithgoogle_4',['RegisterWithGoogle',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a8883283fe1f7df81fefcf8ab7fec4516',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['resendemailconfirmationlink_5',['ResendEmailConfirmationLink',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a538e2154a773be1a14649eb66d7add2c',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]],
  ['resetpassword_6',['ResetPassword',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_authentication_controller.html#a8f25ae69e18d77a38515eeb6c33bb91c',1,'LusoHealthClient::Server::Controllers::AuthenticationController']]]
];
