var searchData=
[
  ['suspendaccountpatient_0',['SuspendAccountPatient',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a4e94c4524872fdfe1e33bfa9dcf98a01',1,'LusoHealthClient::Server::Controllers::ManageController']]],
  ['suspendaccountprofessional_1',['SuspendAccountProfessional',['../class_luso_health_client_1_1_server_1_1_controllers_1_1_manage_controller.html#a6a5e933275f56e946abf9efecc2fd20e',1,'LusoHealthClient::Server::Controllers::ManageController']]]
];
