var searchData=
[
  ['body_0',['Body',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_email_send_dto.html#a49d0acf89a2f95ad25118c7006e146d5',1,'LusoHealthClient::Server::DTOs::Authentication::EmailSendDto']]]
];
