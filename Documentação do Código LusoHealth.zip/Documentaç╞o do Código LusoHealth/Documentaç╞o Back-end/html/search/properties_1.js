var searchData=
[
  ['subject_0',['Subject',['../class_luso_health_client_1_1_server_1_1_d_t_os_1_1_authentication_1_1_email_send_dto.html#ac10eaf3eb61ac90d4d73150b36caca1e',1,'LusoHealthClient::Server::DTOs::Authentication::EmailSendDto']]]
];
