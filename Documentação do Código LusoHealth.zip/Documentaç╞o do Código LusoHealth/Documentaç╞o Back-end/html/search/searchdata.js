var indexSectionsWithContent =
{
  0: "abcdefghjlmoprstu",
  1: "abcdehjlmoprsu",
  2: "l",
  3: "abcdefghlprsu",
  4: "a",
  5: "bst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums",
  5: "properties"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Funções",
  4: "Enumerações",
  5: "Propriedades"
};

